(function () {
	'use strict';

	/**
	 * @ngdoc function
	 * @name app.module:dashboardModule
	 * @description
	 * # dashboardModule
	 * Module of the app
	 */

  	angular.module('global-solusindo', []);

})();
