﻿(function () {
    'use strict';

    angular.module('global-solusindo')
        .controller('ProjectCtrl', ProjectCtrl);

    ProjectCtrl.$inject = ['$scope', '$state', 'projectDtService', 'projectDeleteService', 'projectViewService'];

    function ProjectCtrl($scope, $state, dtService, deleteService, viewService) {
        var self = this;

       dtService.init(self);
        deleteService.init(self);
        viewService.init(self);

        return self;
    }
})();